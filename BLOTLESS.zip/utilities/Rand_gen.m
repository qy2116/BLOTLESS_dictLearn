function RP =  Rand_gen(m,k)
RP = randn(m,k);
end